// FILENAME StFloatADT.h
                    //* YLOPOIHSH STOIBAS ME PINAKA *
              //*TA STOIXEIA THS STOIBAS EINAI TYPOY float*
#include <stdbool.h>

#define StackLimit 80

typedef float StackElementType;

typedef struct  {
    int Top;
    StackElementType Element[StackLimit];
} StackType;

void CreateStack(StackType *Stack);
bool EmptyStack(StackType Stack);
bool FullStack(StackType Stack);
void Push(StackType *Stack, StackElementType Item);
void Pop(StackType *Stack, StackElementType *Item);

