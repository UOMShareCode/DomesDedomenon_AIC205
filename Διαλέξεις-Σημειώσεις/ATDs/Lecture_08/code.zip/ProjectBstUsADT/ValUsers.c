// filename ValUsers.c

// ΕΛΕΓΧΟΣ ΤΑΥΤΟΤΗΤΑΣ ΧΡΗΣΤΩΝ

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "BstUsADT.h"

void Login(BinTreeElementType *UserRec,bool *MoreUsers);
void BuildTree(FILE *UsersFile,BinTreePointer *UserTree, bool *stop);

int main()
{
    FILE *UsersFile;
    BinTreeElementType UserRec;
    BinTreePointer UserTree;
    BinTreePointer LocPtr;
    bool Found, MoreUsers, stop;

    UsersFile = fopen("Users.txt", "r");
    if (UsersFile == NULL)
        printf("Cannot open Users file\n");
    else
    {
        printf("DWSE 0 GIA NA TERMATISEI TO PROGRAMMA\n");
        BuildTree(UsersFile,&UserTree,&stop);
        if (!stop)
        {
            InorderTraversal(UserTree);
            Login(&UserRec,&MoreUsers);
            while (MoreUsers)
            {
                BSTSearch(UserTree,UserRec,&Found,&LocPtr);
                if (Found)
                    if (strcmp(LocPtr->Data.password,UserRec.password)==0)
                        printf("EGKYROS XRHSTHS!\n");
                    else
                        printf("MH EGKYRO password!\n");
                else
                    printf("MH EGKYRO User-Id!\n");
                Login(&UserRec,&MoreUsers);
            }
        }
    }
    return 0;
}

void BuildTree(FILE *UsersFile,BinTreePointer *UserTree, bool *stop)
{
    BinTreeElementType UserRec;
    int nscan;
    char termch;

    CreateBST(&(*UserTree));
    while (true)
    {
        nscan = fscanf(UsersFile, "%d, %10[^\n]%c",
                               &UserRec.id, UserRec.password,&termch);
        if (nscan == EOF) break;
        if (nscan != 3 || termch != '\n')
        {
            printf("Improper file format\n");
            exit(1);
        }
        else
            BSTInsert(&(*UserTree),UserRec);
   }
}

void Login(BinTreeElementType *UserRec,bool *MoreUsers)
{
    printf("User-Id? ");
    scanf("%d",&(UserRec->id));
    if (UserRec->id ==0)
        *MoreUsers=false;
    else
    {
        *MoreUsers=true;
        printf("Password? ");
        scanf("%s",UserRec->password);
   }
}
